import React from "react";
export default class Home extends React.Component {
  render() {
    return (
      <div className="container">
        <center>
          <h1> Register </h1>
          <br />
          <h2>Carlytic</h2>
        </center>
      </div>
    );
  }
}
